
<nav>
            <div class="exp">
            <h2 id="explore">Explore</h2>
            <ul class="no-bullets">
                <li><i class="fa-regular fa-compass"></i><a href="./list.php">Explore Public lists</a></li>
                <li><i class="fa-solid fa-shuffle"></i><a href="./random-list.php">Random List Entry </a></li>
                <li><i class="fa-solid fa-magnifying-glass"></i><a href="./search.php">Search </a></li>
            </ul>
            </div>
    
            <div class="joi">
            <h2 id="join">Join</h2>
            <ul class="no-bullets" >
                <li><i class="fa-solid fa-right-to-bracket"></i><a href="./login.php">Log in</a></li>
                <li><i class="fa-regular fa-square-plus"></i><a href="./create-account.php">Create account</a></li>
            </ul>
            </div>
        </nav>
        
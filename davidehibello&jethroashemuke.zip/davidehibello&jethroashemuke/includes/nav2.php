
<nav>
                <div class="mylist">
                    <h2 id="mylists">My Lists</h2>
                    <ul class="no-bullets">
                        <li><i class="fa-solid fa-umbrella-beach"></i><a href="./Summer.php">Summer Bucket List</a></li>
                        <li><i class="fa-solid fa-building-columns"></i><a href="./college.php">College Bucket List</a></li>
                        <li><i class="fa-solid fa-square-plus"></i><a href="./add-entry.php" style="color: red">Create New List Entry</a></li>
                        
                       
                    </ul>
                </div>

                <div class="exp">
                    <h2 id="explore">Explore</h2>
                    <ul class="no-bullets">
                        <li><i class="fa-regular fa-compass"></i><a href="./list.php">Explore Public lists</a></li>
            <li><i class="fa-solid fa-shuffle"></i><a href="./random-list.php">Random List Entry </a></li>
            <li><i class="fa-solid fa-magnifying-glass"></i><a href="./search.php">Search </a></li>
                    </ul>
                </div>

                <div class="account">
                    <ul class="no-bullets">
                        <li><i class="fa-solid fa-user"></i><a href="">Profile</a></li>
            <li><i class="fa-solid fa-pen-to-square"></i><a href="./edit-account.php">Edit account</a></li>
            <li><i class="fa-solid fa-right-from-bracket"></i><a href="./logout.php">Log out</a></li>
            <li><i class="fa-solid fa-trash"></i><a href="./delete-account.php" class="delete-account-link">Delete account</a></li>
                    </ul>
                </div>
            </nav>
            
            
            